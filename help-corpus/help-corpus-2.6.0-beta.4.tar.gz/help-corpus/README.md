# AccessFlow Help Corpus

The **help corpus** is the versioned documentation bundle the in-app help agent answers from
(epic [#899](https://github.com/bablsoft/accessflow/issues/899)). It is generated from the public
documentation, committed to the repository, and bundled into the backend JAR on the classpath as
`help-corpus/**` — the same mechanism the [connector catalog](../connectors/README.md) uses.

Bundling it is deliberate: the corpus then always matches the running application version, works
in an air-gapped install, and needs no outbound call. By default an install never answers from
documentation for a version it is not running.

The one exception is the opt-in remote refresh (AF-907), off unless an operator sets
`ACCESSFLOW_HELP_CORPUS_REMOTE_REFRESH_ENABLED=true`, which lets an install pick up a documentation
*correction* published between releases. Every release publishes this folder to `gh-pages` as
`help-corpus/help-corpus-<version>.tar.gz`, and a GA release also moves a `help-corpus-index.json`
pointer that pins the archive by SHA-256 — see
[docs/09-deployment.md](../docs/09-deployment.md#remote-corpus-refresh-and-why-it-is-off).

**This folder is generated output. Never hand-edit it.** Edit the documentation, then regenerate:

```bash
node .github/scripts/build-help-corpus.mjs
```

Run it from the repository root and commit the result in the same change. The `help-corpus` CI job
re-runs the generator and fails the build when the committed bundle has drifted from its sources.

## Files

| File | What it is |
|---|---|
| `corpus.jsonl` | One JSON chunk per line: `{id, path, url, anchor, title, section, order, tokens, text}`. Each `text` opens with a breadcrumb line (`AccessFlow Docs > Guides > Run your first governed query > 5. Submit a query`) before the section body — a cheap recall win when the chunk is embedded. |
| `manifest.json` | `{schemaVersion, corpusVersion, generatedAt, sourceCommit, chunkCount, sha256, quickReferenceSha256, sources[]}`. |
| `quick-reference.txt` | A ~6,700-token orientation block — the query lifecycle, the rules that never bend, what AccessFlow is and is not (every way in, no driver or wire protocol, the complete engine / sign-in / AI-provider lists), the sidebar menu with each destination's label, menu path and permissions, the screens that have no menu entry, the exact control labels on the main task flows, and what the documentation covers. Substituted for retrieved context whenever retrieval is unavailable (no pgvector, no embedding provider, or an Anthropic-only install), so the agent still answers correctly; it just cannot cite a section. |

The artifact is chunked **text**, never precomputed embeddings. Vector dimensions and the embedding
model are the operator's choice — OpenAI `text-embedding-3-small` is 1536, Ollama
`nomic-embed-text` is 768, and Anthropic ships no embedding API at all — so a release cannot know
which. Each install embeds this text locally with its own configured model.

`corpusVersion` is `sha256(corpus.jsonl)[0..12]`: content-derived, not the application version.
Re-ingestion is therefore an idempotent string compare across replicas and restarts, and a
documentation typo fix re-embeds one chunk rather than all of them — chunk `id` is
`sha256(path + '#' + anchor + ':' + order)[0..16]`.

## What goes in, and what does not

Included: **every** `.html` file under `website/`, plus `docs/09-deployment.md` (the operator
env-var reference, which nothing on the website covers). The generator walks the tree rather than
naming folders, and **fails on any page it cannot classify** — so a new documentation area has to
be given a `SECTION_RULES` section label or an explicit exclusion, and cannot be silently dropped.

Included as well, and derived rather than written: the app's **UI vocabulary** (#925) — see
[below](#the-ui-vocabulary-and-why-it-is-derived).

Included in `quick-reference.txt` only, hand-written like the lifecycle and the rules: a
**product-facts block** ("What AccessFlow is, and what it is not") — see
[below](#what-accessflow-is-not-and-why-the-corpus-has-to-say-so).

Excluded on purpose:

- **`website/roadmap/`** — it describes unbuilt work, and an agent that retrieves it will
  confidently explain features the user does not have.
- **`website/changelog/`** — version-specific.
- **Every page's shared nav, sidebar and footer** — otherwise ~10k words of near-duplicate link
  text would dominate similarity search across all 50 sources.
- **Decorative product mock-ups** (`aria-hidden="true"`, or the site's `mock` class) — the
  homepage's animated editor demo alone flattens to ~685 tokens of invented query ids, users and
  row counts. Dense with `audit`, `QUERY_EXECUTED` and `HMAC-SHA256`, it would rank near the top
  for "what does the audit log record?", and the agent would recite fabricated data back as
  documentation.
- **Sections under 40 tokens** — a chapter label plus a "Last updated" stamp is not an answer, and
  ~23 of them were near-identical across pages.

## How the generator works

Content is taken from each page's `<main>` element, minus its `<aside>`, `<nav>`, `<script>`,
`<style>`, `<svg>` and `<button>` boilerplate and its decorative mock-ups, then split on `<h2>` /
`<h3>` boundaries (`##` / `###` for markdown). The heading's `id` becomes the chunk `anchor` when
it has one. Any section over 800 tokens — the same budget `RagProperties.chunkSize` uses at
runtime — is split further on paragraph, then line, then word boundaries.

`order` counts parts **within a section**, not across the page, so a chunk's `id` depends only on
its own anchor and part index. Inserting a section therefore does not renumber the ones after it,
which is what makes a documentation edit re-embed the sections it touched rather than the page.

The script asserts loudly rather than silently emitting a broken bundle. It fails when a page
under `website/` matches no section rule and no exclusion, when the chunk count leaves the 350–600
range, when any chunk exceeds the token budget, when two chunks collide on `id`, when an excluded
path appears, or when a page has no `<main>`, no `<h1>` or no canonical URL.

The route table and lifecycle summary that `quick-reference.txt` is rendered from are declared at
the bottom of `.github/scripts/build-help-corpus.mjs`. That table is **cross-checked against
`frontend/src/App.tsx` in both directions**: a route the application serves that nobody described
fails the build, and so does a description of a route that no longer exists. Adding a route means
adding a line saying what the screen is for (or listing it in `ROUTES_NOT_LISTED`) — otherwise the
orientation block the agent falls back to would quietly describe an app that no longer exists.

## The UI vocabulary, and why it is derived

Everything above describes the product in the documentation's words. That is not what a user
clicks. Asked how to submit a query, the agent answered "open the SQL editor (`/editor`)" — a name
the sidebar does not use for that entry, and a URL where a menu path belongs. It had nothing else
to offer: not one string in the corpus came from the frontend, so the sixteen group and
sub-section names the menu is organised into were unreachable, and so was every button label a
step-by-step answer is made of. An instruction naming a menu item that is not there reads
authoritative and sends the reader looking for nothing.

So three more inputs are **parsed, never paraphrased**:

| Source | What is taken from it |
|---|---|
| `frontend/src/components/common/Sidebar.tsx` | The `GROUPS` literal: which group and sub-section each destination sits in, its route, and the permissions that reveal it. |
| `frontend/src/locales/en.json` | Every `nav.*` label, and the curated control labels named by `CONTROL_VOCABULARY`. |
| `frontend/src/utils/reviewHubTabs.ts` | `REVIEW_HUB_TAB_PERMISSION`, from which the review queue's any-of permission set is derived. |

They produce one synthetic page, `Finding your way around the AccessFlow interface`, in a
`Navigation` section: the sidebar menu (label, full `Group → Subgroup → Item` path, route,
permissions and purpose for every destination), the screens that have **no** menu entry and how
they are reached instead, and the exact button and field labels on the submit → analyse → review →
execute path. The same block is rendered into `quick-reference.txt`, which is the mode with no
citations at all and therefore the one most worth getting literally right.

The notes beside each control are the one hand-written part, and they carry what the label alone
cannot: that **Analyze** gates **Submit for review** on an AI-enabled datasource, that
`· required for review` beside **Justification** is advisory rather than a validation rule (the
identical note on the Emergency access modal is not), and which controls appear only for some
engines. A label quoted without its condition is the same failure in a smaller box.

`CONTROL_VOCABULARY` is a curated list, not a dump: `en.json` holds thousands of strings, and the
tooltips and toasts among them would drown retrieval. Only the *reference* is hand-written — every
label is resolved from `en.json`, so what the corpus quotes is what the control says.

The generator fails, loudly, when these stop agreeing:

- a `nav.*` or control key that no longer resolves, or one whose value interpolates (`{{count}}`
  would reach the reader literally);
- a sidebar destination whose route `ROUTES` does not describe;
- a `ROUTES` line that claims a screen is reached some other way while the sidebar lists it, or one
  that claims neither a menu entry nor another way in;
- a `GROUPS` literal whose shape the parser no longer recognises — it never degrades to a partial
  nav tree, which would silently drop destinations.

Because CI's `help-corpus` paths filter watches all three files, renaming a menu entry or moving it
between groups fails the drift guard until the bundle is regenerated.

## What AccessFlow is not, and why the corpus has to say so

Asked whether a C# application could reach AccessFlow over ODBC or ADO.NET, the agent answered "I
don't know": every retrieved excerpt described how AccessFlow's own engines connect *outbound*
(JDBC drivers, native SDKs), and nothing anywhere said that AccessFlow exposes no database wire
protocol inbound. The documentation described what the product does, page by page, and never once
what it is not — and a prompt that forbids guessing cannot infer a negative from silence.

Two things fixed that, and they move together:

- The **Integrations & boundaries** chapter (`website/docs/integrations/`) is the one page that
  states every way in, what AccessFlow is not (no ODBC/JDBC/ADO.NET driver, no connection string,
  no SaaS edition), and the supported engines, sign-in methods and AI providers — each list marked
  **complete**. It is ingested like any other page, so the agent cites it with a link.
- `HelpChatPromptRenderer` lets the model say "AccessFlow does not offer it" **only** from a list an
  excerpt marks complete. With `top_k` excerpts in view, "absent from what I was shown" must never
  become "not supported" — a Neo4j question answered from MongoDB chunks would otherwise get a
  confident wrong no.

The quick reference carries the same facts in `PRODUCT_FACTS`, placed above the navigation block
because the renderer truncates the tail first. Its engine line is **derived** from
`connectors/*/connector.json` (`name`), and the generator fails when the chapter does not name a
connector the catalog ships — a list that claims to be complete and is not would turn the prompt
rule into a confident falsehood. Adding a connector therefore means adding it under
`#supported-engines` on the chapter and regenerating.

## Determinism

Running the generator twice in a row produces byte-identical files, which is what the CI drift
guard (`git diff --exit-code help-corpus/`) relies on. No wall-clock value reaches `corpus.jsonl`
or `quick-reference.txt`, and `manifest.json`'s `generatedAt` / `sourceCommit` are carried over
verbatim from the existing manifest whenever the content digests are unchanged — so a regeneration
of untouched sources is a no-op in git.

The carry-over compares against the manifest already on disk, so one local sequence leaves a
cosmetic diff: edit a source, regenerate, revert the edit, regenerate again, and `generatedAt`
refreshes even though the content came back to where it started. `git checkout -- help-corpus/`
clears it. CI never hits this — it regenerates once from a committed tree.
